<?php
class bug39542 {
	function bug39542() {
		echo "ok\n";
	}
}
?>
