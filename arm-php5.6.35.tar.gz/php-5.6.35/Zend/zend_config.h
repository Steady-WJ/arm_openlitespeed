#include <../main/php_config.h>
#if defined(APACHE) && defined(PHP_API_VERSION)
#undef HAVE_DLFCN_H
#endif
