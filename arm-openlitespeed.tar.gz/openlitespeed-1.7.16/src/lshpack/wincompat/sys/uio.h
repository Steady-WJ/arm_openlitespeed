#ifndef WINCOMPAT_SYS_UIO_H
#define WINCOMPAT_SYS_UIO_H

struct iovec
{
	void 	*iov_base;
	size_t	 iov_len;
};

#endif
