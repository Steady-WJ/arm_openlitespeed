# Source this file
export USE_QPACK_05=0
ARGS='fuzz-decode -i fuzz/decode/d/preamble -f @@ -s 100 -t 256'
