# Source this file
export USE_QPACK_05=1
ARGS='interop-decode -i @@ -o /dev/null -s 100 -t 256'
